<?php

return [
    'plugin' => [
        'name' => 'latihan',
        'description' => 'No description provided yet...',
    ],
    'permissions' => [
        'some_permission' => 'Some permission',
    ],
];
