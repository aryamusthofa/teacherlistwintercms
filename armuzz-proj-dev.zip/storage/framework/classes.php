<?php return array (
  'Winter\\Demo\\Plugin' => 'plugins\\winter\\demo\\Plugin.php',
  'Cms\\Controllers\\Index' => 'modules/cms/controllers\\Index.php',
  'Backend\\Controllers\\Auth' => 'modules/backend/controllers\\Auth.php',
  'Winter\\Demo\\Components\\Todo' => 'plugins\\winter\\demo\\components\\Todo.php',
);